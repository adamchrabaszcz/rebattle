rebattle brand kit
==================

logos/      full, name, mark and badge, each on-dark, on-light, mono-dark, mono-white (SVG + PNG)
instagram/  the profile picture, and the video cover for Reels and Stories (1080x1920)
how/        how the logo is made: the steps, and the whole sheet (SVG + PNG)
share-preview.png / .svg   the link preview (1200x630)
logo-usage.svg             do's and don'ts

How to use them, the colours and the type: https://rebattle.app/brand
The rebattle name and logo are not under the code's MIT licence. Use them to show that your event
runs on rebattle; not as your own brand or for a copy of the app.
